﻿using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using Simple_API_Assessment.Models;

namespace Simple_API_Assessment.Data
{
    public class DataContext : DbContext
    {
        public DataContext(DbContextOptions<DataContext> options) : base(options) { }

        public DbSet<Applicant> Applicants { get; set; }
        public DbSet<Skill> Skills { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Applicant>().HasData(
                new Applicant
                {
                    Id = 1,
                    Name = "Daniel",
                }
            );

            modelBuilder.Entity<Skill>().HasData(
                new Skill { Id = 1, Name = "Programming", ApplicantId = 1 },
                new Skill { Id = 2, Name = "Database Management", ApplicantId = 1 }
            );
        }
    }
}
