﻿using Simple_API_Assessment.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Simple_API_Assessment.Data.Repository
{
    public interface IApplicantRepository
    {
        Task<IEnumerable<Applicant>> GetAllApplicants();
        Task<Applicant> GetApplicantById(int id);
        Task<Applicant> CreateApplicant(Applicant applicant);
        Task<Applicant> UpdateApplicant(int id, Applicant applicant);
        Task<bool> DeleteApplicant(int id);
    }
}
