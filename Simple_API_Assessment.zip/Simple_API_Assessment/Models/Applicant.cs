﻿using static System.Runtime.InteropServices.JavaScript.JSType;

namespace Simple_API_Assessment.Models
{
    public class Applicant
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public List<Skill>? Skills { get; set; }

    }
}
