﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Simple_API_Assessment.Data;
using Simple_API_Assessment.Data.Repository;
using Simple_API_Assessment.Models;

namespace Simple_API_Assessment.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ApplicantController : ControllerBase
    {
        private readonly IApplicantRepository _applicantRepository;
        public ApplicantController(IApplicantRepository applicantRepository)
        {
            _applicantRepository = applicantRepository;
        }

        [HttpGet]
        public async Task<IActionResult> GetApplicants()
        {
            return Ok(await _applicantRepository.GetAllApplicants());
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<Applicant>> GetApplicant(int id)
        {
            var applicant = await _applicantRepository.GetApplicantById(id);

            if (applicant == null)
            {
                return NotFound();
            }

            return applicant;
        }

        [HttpPost]
        public async Task<ActionResult<Applicant>> PostApplicant(Applicant applicant)
        {
            var newApp = await _applicantRepository.CreateApplicant(applicant);

            return CreatedAtAction(nameof(GetApplicant), new { id = newApp.Id }, newApp);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> PutApplicant(int id, Applicant applicant)
        {
            if (id != applicant.Id)
            {
                return BadRequest();
            }

            var updatedApp = _applicantRepository.UpdateApplicant(id, applicant);

            return Ok(updatedApp);
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteApplicant(int id)
        {
            var applicant = await _applicantRepository.DeleteApplicant(id);
            if (applicant == null)
            {
                return NotFound();
            }

            return Ok(applicant);
        }

        private bool ApplicantExists(int id)
        {
            var app = _applicantRepository.GetApplicantById(id);
            return app != null;
        }
    }
}
